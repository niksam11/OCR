from flask import Flask, render_template, request, send_from_directory, flash,send_file
from PyPDF2 import PdfReader, PdfWriter
from PIL import Image
from pytesseract import pytesseract
import os
from werkzeug.utils import secure_filename
from pdf2image import convert_from_path
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase import pdfmetrics
from docx import Document
import time
import tempfile
from io import BytesIO
import zipfile
import time
import threading
from reportlab.lib.colors import Color
from PIL import Image, ImageEnhance, ImageFilter


app = Flask(__name__)
app.secret_key = "OCR_flask"

@app.route('/')
def home():
    return render_template('index.html')

@app.route("/upload")
def uploadPage():
    return render_template("upload.html")

# # Tesseract path
pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"


# Paths for language data and directories
TEMP_DIR = tempfile.mkdtemp()  # Use system-generated temporary directory
OUTPUT_DIR = "output"

UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# if not os.path.exists(OUTPUT_DIR):
#     os.makedirs(OUTPUT_DIR)


######### OCR################


# Preprocess image for better OCR results
def preprocess_image(image):
    """Enhance image quality for better OCR accuracy."""
    # Convert to grayscale
    image = image.convert("L")
    # Increase contrast
    enhancer = ImageEnhance.Contrast(image)
    image = enhancer.enhance(2)
    # Apply sharpening
    image = image.filter(ImageFilter.SHARPEN)
    return image

# Extract text with improved configurations
def extract_text(image, lang, psm_mode=6, oem_mode=3):
    """Extract text from an image with custom Tesseract configurations."""
    try:
        custom_config = f'--psm {psm_mode} --oem {oem_mode}'
        return pytesseract.image_to_string(image, lang=lang, config=custom_config)
    except Exception as e:
        return f"Error during OCR: {e}"

# Extract text from PDF
def extract_text_from_pdf(pdf_path, lang, psm_mode=6, oem_mode=3):
    """Extract text from a PDF by converting each page to an image."""
    try:
        images = convert_from_path(pdf_path, dpi=300, use_pdftocairo=True)
        text = ""
        for image in images:
            processed_image = preprocess_image(image)
            text += extract_text(processed_image, lang, psm_mode, oem_mode)
        return text
    except Exception as e:
        return f"Error during PDF OCR: {e}"

# Save extracted text as a Word document
def save_as_word(text, file_path):
    """Save extracted text as a Word document."""
    doc = Document()
    doc.add_paragraph(text)
    doc.save(file_path)

# Save extracted text as a PDF
def save_as_pdf(text, file_path):
    """Save extracted text as a PDF."""
    font_path = r"C:\Program Files\Tesseract-OCR\tessdata\Noto_Sans_Devanagari\NotoSansDevanagari-Regular.ttf"
    pdfmetrics.registerFont(TTFont("NotoSansDevanagari", font_path))
    pdf_canvas = canvas.Canvas(file_path, pagesize=letter)
    pdf_canvas.setFont("NotoSansDevanagari", 12)

    lines = text.split("\n")
    y_position = 750
    for line in lines:
        pdf_canvas.drawString(50, y_position, line)
        y_position -= 15
        if y_position < 50:  # Add a new page if the text exceeds the page height
            pdf_canvas.showPage()
            y_position = 750

    pdf_canvas.save()

# Route for OCR text extraction
@app.route('/ocr_text_extraction', methods=['GET', 'POST'])
def ocr_text_extraction():
    extracted_text = None
    download_file = None

    if request.method == 'POST':
        file = request.files.get('file')
        language = request.form.get('language', 'eng')  # Default to English if no language is selected
        psm_mode = request.form.get('psm_mode', '6')
        output_format = request.form.get('output_format', 'text')  # Default to text format

        if not file:
            flash("No file uploaded!", 'danger')
            #return render_template('ocr_text_extraction.html')

        filename = secure_filename(file.filename)
        # file_path = os.path.join(TEMP_DIR, filename)
        file_path = os.path.join(UPLOAD_FOLDER, filename)


        try:
            # Save file to temporary directory
            file.save(file_path)

            # Process file
            if file.filename.endswith('.pdf'):
                extracted_text = extract_text_from_pdf(file_path, language,psm_mode=int(psm_mode))
            else:
                with Image.open(file_path) as image:
                    processed_image = preprocess_image(image)
                    extracted_text = extract_text(processed_image, language, psm_mode=int(psm_mode))

            # Prepare output file
            output_file_name = f"extracted_{filename.split('.')[0]}.{output_format}"
            output_path = os.path.join(OUTPUT_DIR, output_file_name)

            if output_format == 'text':
                with open(output_path, 'w', encoding='utf-8') as f:
                    f.write(extracted_text)
            elif output_format == 'pdf':
                save_as_pdf(extracted_text, output_path)
            elif output_format == 'word':
                save_as_word(extracted_text, output_path)

            download_file = output_file_name

        except Exception as e:
            flash(f"An error occurred: {e}", 'danger')

    return render_template('options.html', extracted_text=extracted_text, download_file=download_file, file=request.files.get('file'))

# Route to download files
@app.route('/download/<filename>')
def download_file(filename):
    return send_from_directory(OUTPUT_DIR, filename, as_attachment=True)

@app.route('/uploads/<filename>')
def uploaded_file1(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)






################### watermark #######################




@app.route("/add_watermark", methods=["GET", "POST"])
def apply():
    if request.method == "POST":
        # Retrieve form data from the POST request
        watermark_type = request.form.get("watermark_type", "text")
        position_x = int(request.form.get("position_x", 250))
        position_y = int(request.form.get("position_y", 250))
        rotation = int(request.form.get("rotation", 0))
        opacity = float(request.form.get("opacity", 0.5))
        font_size = int(request.form.get("font_size", 20))
        text_content = request.form.get("text", "Watermark")
        font_color_hex = request.form.get("font_color", "#FF0000")
        watermark_pages = request.form.get("watermark_pages", "all")

        font_color_rgb = tuple(int(font_color_hex[i:i+2],16) / 255.0 for i in (1,3,5))

        if watermark_pages == "all":
            page_numbers = None  # None will indicate all pages
        else:
            page_numbers = [int(page.strip()) - 1 for page in watermark_pages.split(',')]

        # Save the uploaded PDF
        if "pdf_file" not in request.files:
            return "Please upload a PDF file", 400

        pdf_file = request.files["pdf_file"]
        pdf_path = os.path.join(UPLOAD_FOLDER, "uploaded.pdf")
        pdf_file.save(pdf_path)

        watermarked_pdf_path = os.path.join(UPLOAD_FOLDER, "watermarked.pdf")


        # Generate watermark PDF
        watermark_pdf = BytesIO()
        if watermark_type == "text":
            generate_text_watermark(watermark_pdf, text_content, position_x, position_y, rotation, font_size, opacity,font_color_rgb)
    
        elif watermark_type == "image":
            image_path = os.path.join(UPLOAD_FOLDER, "watermark_image.png")
        
            if "watermark_image" in request.files:
                image_width = int(request.form.get('image_width', 100))
                image_height = int(request.form.get('image_height', 90))
                request.files["watermark_image"].save(image_path)

            generate_image_watermark(watermark_pdf, image_path, position_x, position_y, rotation, opacity,image_width, image_height)

        watermark_pdf.seek(0)

        # Apply watermark to PDF
        apply_watermark_to_pdf(pdf_path, watermarked_pdf_path, watermark_pdf,page_numbers)

        return render_template("add_watermark.html", pdf_url="/uploads/uploaded.pdf", preview_url="/uploads/watermarked.pdf")

    return render_template("add_watermark.html")

@app.route("/uploads/<filename>")
def uploaded_file(filename):
    return send_file(os.path.join(UPLOAD_FOLDER, filename))



def generate_text_watermark(output, text, x, y, rotation, font_size, opacity,font_color_rgb):
    """
    Generate a PDF containing the text watermark.
    """
    text_canvas = canvas.Canvas(output, pagesize=letter)
    text_canvas.setFont("Helvetica", font_size)

    # Set transparent color for opacity
    transparent_color = Color(*font_color_rgb, alpha=opacity)
    text_canvas.setFillColor(transparent_color)

    text_canvas.translate(x, y)
    text_canvas.rotate(rotation)
    text_canvas.drawString(0, 0, text)
    text_canvas.save()


def generate_image_watermark(output, image_path, x, y, rotation,opacity,image_width, image_height):
    """
    Generate a PDF containing the image watermark.
    """
   

    image_canvas = canvas.Canvas(output, pagesize=letter)

     # Open and resize the image
    with Image.open(image_path) as img:
        
        if image_width and image_height:
            img = img.resize((image_width, image_height))
        
        # Apply rotation
        img = img.rotate(rotation, expand=True)
        
        # Apply opacity (if needed)
        img = img.convert("RGBA")  # Convert to RGBA for alpha transparency
        datas = img.getdata()
        new_data = []
    
        for item in datas:
             # Adjust the alpha channel (opacity)
            r, g, b, a = item  # Extract RGBA values
            new_a = int(a * opacity)  # Modify the alpha channel based on opacity value
            new_data.append((r, g, b, new_a))  # Apply the new alpha value
        img.putdata(new_data)  # Apply the new transparency data

        # Save modified image as temporary file
        image_path = os.path.join(UPLOAD_FOLDER, "watermark_image.png")

        img.save(image_path)

        try:
            # Create PDF content and apply the watermark image to it
            image_canvas.translate(x, y)  
            image_canvas.rotate(rotation)  
            image_canvas.drawImage(image_path, 0, 0, width=img.width, height=img.height, mask="auto")  # Draw the image
            image_canvas.save()  # Finalize and save the PDF

        finally:
            # Optionally, delete the temporary image after use
            if os.path.exists(image_path):
                os.remove(image_path)

def apply_watermark_to_pdf(input_pdf_path, output_pdf_path, watermark_pdf,page_numbers):
    """
    Apply the watermark from a PDF to all pages of another PDF.
    """
    reader = PdfReader(input_pdf_path)
    writer = PdfWriter()

    watermark_reader = PdfReader(watermark_pdf)
    watermark_page = watermark_reader.pages[0]

    
    for i ,page in enumerate(reader.pages):
        if page_numbers is None or i in page_numbers:
            page.merge_page(watermark_page)
        writer.add_page(page)

    with open(output_pdf_path, "wb") as output_file:
        writer.write(output_file)


@app.route("/download")
def download():
    watermarked_pdf_path = os.path.join(UPLOAD_FOLDER, "watermarked.pdf")

    response = send_file(watermarked_pdf_path, as_attachment=True, download_name="watermarked.pdf")
    
    return response

    ##########Rotate pdf ################    

@app.route('/rotate', methods=['GET','POST'])
def rotate_pdf():
    if request.method =="POST":
        try:
            # Get uploaded files and angle
            pdf_files = request.files.getlist('pdfs')
            angle = int(request.form.get("angle", 0))

            if not pdf_files or len(pdf_files) == 0:
                return "No files uploaded", 400

            rotated_files = []

            for pdf_file in pdf_files:
                if pdf_file.filename == '':
                    continue  # Skip empty files

                filename = pdf_file.filename
                file_path = os.path.join(UPLOAD_FOLDER, filename)
                pdf_file.save(file_path)

                # Rotate the PDF
                output_path = os.path.join(OUTPUT_DIR, filename)
                reader = PdfReader(file_path)
                writer = PdfWriter()

                for page in reader.pages:
                    page.rotate(angle)
                    writer.add_page(page)

                with open(output_path, 'wb') as f:
                    writer.write(f)

                rotated_files.append(output_path)

            if len(rotated_files) == 1:
                # Send a single file if only one is uploaded
                return send_file(
                    rotated_files[0],
                    mimetype="application/pdf",
                    as_attachment=True,
                    download_name=os.path.basename(rotated_files[0])
                )
            else:
                # Create a ZIP file if multiple files are uploaded
                zip_filename = "rotated_pdfs.zip"
                zip_path = os.path.join(OUTPUT_DIR, zip_filename)
                with zipfile.ZipFile(zip_path, 'w') as zipf:
                    for file_path in rotated_files:
                        zipf.write(file_path, os.path.basename(file_path))

                return send_file(
                    zip_path,
                    mimetype="application/zip",
                    as_attachment=True,
                    download_name=zip_filename
                )
        except Exception as e:
            return f"Error: {e}", 500
            
        
    # Handle GET requests
    return render_template('rotate.html')
    



# Function to clean up old files
def cleanup_folder(folder, timeout):
    while True:
        now = time.time()
        for filename in os.listdir(folder):
            file_path = os.path.join(folder, filename)
            if os.path.isfile(file_path):
                file_age = now - os.path.getmtime(file_path)
                if file_age > timeout:
                    os.remove(file_path)
        time.sleep(60)  # Run cleanup every 1 minute

# Start background cleanup threads
threading.Thread(target=cleanup_folder, args=(UPLOAD_FOLDER, 300), daemon=True).start()  # 5 minutes timeout
threading.Thread(target=cleanup_folder, args=(OUTPUT_DIR, 300), daemon=True).start()  # 5 minutes timeout


if __name__ == "__main__":
    app.run(debug=True)
